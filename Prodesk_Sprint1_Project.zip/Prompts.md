Prompt 1: Create a responsive landing page using HTML, CSS and JavaScript.
Prompt 2: Add dark mode toggle.
Prompt 3: Make layout responsive with Flexbox and Grid.

document.getElementById('themeBtn').addEventListener('click',()=>{
document.body.classList.toggle('dark');
});
# Prodesk IT Landing Page

Responsive landing page using HTML, CSS and JavaScript.

## Features
- Responsive design
- Sticky navbar
- Dark mode toggle
- Service cards
